const express = require('express');
const router = express.Router();

const da = require('../data-access');

router.get('/', (req, res) => {
    res.render("employees/index", { pageTitle: "Employees View", empList: da.getAllEmployees() });
});

module.exports = router;