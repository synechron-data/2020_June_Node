const express = require('express');
const router = express.Router();

const da = require('../data-access');

router.get('/employees', (req, res) => {
    res.json(da.getAllEmployees());
});

module.exports = router;