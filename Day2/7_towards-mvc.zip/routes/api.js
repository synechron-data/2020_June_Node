const express = require('express');
const router = express.Router();

const emp_api_Ctrl = require('../controllers/employee-api-controller');

router.get('/employees', emp_api_Ctrl.index);

router.get('/employees/:empid', emp_api_Ctrl.getEmployee);

module.exports = router;