const express = require('express');
const router = express.Router();

const empCtrl = require('../controllers/employee-controller');

router.get('/', empCtrl.index);

router.get('/details/:empid', empCtrl.details);

module.exports = router;