const da = require('../data-access');

exports.index = (req, res) => {
    res.json(da.getAllEmployees());
};

exports.getEmployee = (req, res) => {
    var id = req.params.empid;

    res.json(da.getEmployee(id));
};