const da = require('../data-access');

exports.index = (req, res) => {
    res.render("employee/index", { pageTitle: "Employees Index View", empList: da.getAllEmployees() });
};

exports.details = (req, res) => {
    var id = req.params.empid;
    // console.log(id);

    res.render("employee/details", { pageTitle: "Employee Details View", employee: da.getEmployee(id) });
};

exports.create_get = (req, res) => {
    res.render("employee/create", { pageTitle: "Create Employee View" });
};

exports.create_post = (req, res) => {
    var { eid, ename } = req.body;
    var employee = { id: eid, name: ename };

    da.insertEmployee(employee);
    res.redirect("/employees");
};