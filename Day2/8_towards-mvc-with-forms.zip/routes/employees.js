const express = require('express');
const router = express.Router();

const empCtrl = require('../controllers/employee-controller');

router.get('/', empCtrl.index);

router.get('/details/:empid', empCtrl.details);

router.get('/create', empCtrl.create_get);

router.post('/create', empCtrl.create_post);

module.exports = router;