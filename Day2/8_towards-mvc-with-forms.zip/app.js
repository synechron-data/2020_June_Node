const express = require('express');
const logger = require('morgan');
const session = require('express-session');
const path = require('path');

const indexRouter = require('./routes/index');
const employeesRouter = require('./routes/employees');
const apiRouter = require('./routes/api');

const app = express();

app.set("view engine", "pug");

app.use(express.static(path.join(__dirname, 'public')));
app.use('/css', express.static(path.join(__dirname, './node_modules/bootstrap/dist/css')));
app.use('/fonts', express.static(path.join(__dirname, './node_modules/bootstrap/dist/fonts')));
app.use('/scripts', express.static(path.join(__dirname, './node_modules/jquery/dist')));
app.use('/scripts', express.static(path.join(__dirname, './node_modules/bootstrap/dist/js')));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(session({
    secret: 'checking',
    resave: true,
    saveUninitialized: true
}));

app.use('/', indexRouter);
app.use('/employees', employeesRouter);
app.use('/api', apiRouter);

module.exports = app;