const fs = require('fs');

let fData = "";

// var readstream = fs.createReadStream('./file1.txt');

// // Chunk Size - 64 * 1024

// readstream.on('open', () => {
//     console.log("File Opened....");
// });

// readstream.on('data', (chunk) => {
//     fData += chunk;
// });

// readstream.on('end', () => {
//     console.log("End Event - ", fData);
// });

// --------------------------- File Copy

var readstream = fs.createReadStream('./file1.txt');
var writestream = fs.createWriteStream('./file2.txt');

readstream.on('data', (chunk) => {
    writestream.write(chunk);
});

readstream.on('end', () => {
    console.log("File Copied.....");
    writestream.close();
});
