// const fs = require('fs');

// var readstream = fs.createReadStream('./file1.txt');
// var writestream = fs.createWriteStream('./file1-copy.txt');

// readstream.pipe(writestream);
// console.log("File Copied....");

const fs = require('fs');
const zlib = require('zlib');

fs.createReadStream('./file1.txt')
    .pipe(zlib.createGzip())
    .pipe(fs.createWriteStream('./file1.txt.gz'));

console.log("File Compressed....");