const readline = require('readline');

var rl = readline.createInterface({
    input: process.stdin,           // ReadStream
    output: process.stdout          // WriteStream
});

// rl.question("Enter a number: ", (input) => {
//     console.log(`You entered ${input}`);
//     rl.close();
// });

// console.log("\n......Last Line......\n");
// rl.close();

// rl.question("Enter a first number : ", (input1) => {
//     rl.question("Enter a second number: ", (input2) => {
//         var sum = parseInt(input1) + parseInt(input2);
//         console.log(`Result is: ${sum}`);
//         rl.close();
//     });
// });

function enterNumberOne() {
    return new Promise((resolve) => {
        rl.question("Enter a first number : ", (input) => {
            var num = parseInt(input);
            resolve(num);
        });
    })
}

function enterNumberTwo(n1) {
    return new Promise((resolve) => {
        rl.question("Enter a second number : ", (input) => {
            var num = parseInt(input);
            resolve([n1, num]);
        });
    })
}

function add([n1, n2]) {
    var sum = n1 + n2;
    console.log(`Result is: ${sum}`);
    rl.close();
}

enterNumberOne().then(enterNumberTwo).then(add);