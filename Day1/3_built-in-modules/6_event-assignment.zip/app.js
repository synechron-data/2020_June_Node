const Account = require('./Account');
const SMS = require('./SMS');
const Email = require('./Email');

const sms = new SMS();
const email = new Email();

let a1 = new Account(1, 1000, 6);

a1.on('depositSuccess', (balance) => {
    console.log("\nAmount Deposited Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    console.log("\nAmount Withdrawn Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    console.log("\nAmount Withdraw Failed...");
    console.log(`New Account Balance is: INR ${balance}`);
});

// Code Added - SMS
a1.on('depositSuccess', (balance) => {
    sms.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    sms.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    sms.send(`Amount Withdraw Failed - Your Account Balance is: INR ${balance}`);
});

// Code Added - Email
a1.on('depositSuccess', (balance) => {
    email.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    email.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    email.send(`Amount Withdraw Failed - Your Account Balance is: INR ${balance}`);
});

a1.deposit(1000);
a1.withdraw(2000);
a1.withdraw(1000);