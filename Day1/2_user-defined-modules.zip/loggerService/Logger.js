class Logger {
    log(message){
        console.log(`${message}, logged using Logger Class Method`);
    }
}

module.exports = Logger;