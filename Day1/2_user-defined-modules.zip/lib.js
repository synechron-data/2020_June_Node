// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

var fname = "Manish";
var lname = "Sharma";

// module.exports = { firstname: fname, lastname: lname };
// exports = { firstname: fname, lastname: lname };  // Will not work

// Named Exports
// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function(message){
//     console.log("From Lib - ", message);
// }

exports.firstname = fname;
exports.lastname = lname;
exports.log = function (message) {
    console.log("From Lib - ", message);
}

// exports.Employee = class Employee {
//     constructor(name) {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     setName(value) {
//         this._name = value;
//     }
// }

class Employee {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }
}

exports.Employee = Employee;