const Logger = require('./Logger');
let instance;

module.exports.getLogger = function () {
    if (!instance)
        instance = new Logger();
    return instance;
}