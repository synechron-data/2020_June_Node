// require("./lib");

// const lib = require("./lib");
// console.log(lib);

// lib.log("Hi from App Module");

// var e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const { Employee } = require("./lib");
// var e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// ------------------------------------------------------------

// const logger = require('./logger');

// ------------------------------------------------------------

// const loggerService = require('./loggerService');
// loggerService.log("Hello from Main Module");

// ------------------------------------------------------------
// const loggerSingle = require('./loggerSingle');

// let l1 = loggerSingle.getLogger();
// l1.log("Hi from App");

// let l2 = loggerSingle.getLogger();
// l2.log("Hi from App");

// console.log(l1 === l2);

// ------------------------------------------------------------
// const loggerFactory = require('./loggerFactory');

// let dbLogger = loggerFactory.DBLFactory.getLogger();
// let flLogger = loggerFactory.FLFactory.getLogger();

const { DBLFactory, FLFactory } = require('./loggerFactory');

let dbLogger = DBLFactory.getLogger();
let flLogger = FLFactory.getLogger();

dbLogger.log("Hello from App Module");
flLogger.log("Hello from App Module");