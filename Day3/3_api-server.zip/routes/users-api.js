var express = require('express');
var router = express.Router();

const userApiCtrl = require('../controllers/user-api-controller');
const accCtrl = require('../controllers/account-controller');

// Enabling CORS
router.use(function (req, res, next) {
    // update * to match the domain you will make the request from
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

const jwt = require('jsonwebtoken');

router.use(function (req, res, next) {
    var token = req.headers["x-access-token"];

    if (token) {
        jwt.verify(token, "test", function (err, decoded) {
            if (err) {
                res.send(403).json({
                    success: false,
                    message: "Invalid Token Found"
                });
            } else {
                next();
            }
        });
    } else {
        res.send(403).json({
            success: false,
            message: "No Token Found"
        });
    }
});

router.get('/', userApiCtrl.getUsers);

module.exports = router;